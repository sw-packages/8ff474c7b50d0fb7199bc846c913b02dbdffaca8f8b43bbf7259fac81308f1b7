Documentation headers
=====================

These headers are not meant to be included.  They are documentation, not code.
Keeping them in this form lets the documentation system process them in the
same way as in-line documentation, supporting references back and forth between
the two kinds.
